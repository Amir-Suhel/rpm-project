insert into user values('harshverm776','password123',1);
insert into user values('abhishek','password123',2);
insert into user values('harshdeep','password123',9);
insert into user values('harshit','password123',3);

