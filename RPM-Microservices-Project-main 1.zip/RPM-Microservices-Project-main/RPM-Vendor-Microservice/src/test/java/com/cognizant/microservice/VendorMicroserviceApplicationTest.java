package com.cognizant.microservice;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VendorMicroserviceApplicationTest {

	@Test
	void testMain() {
		assertTrue(true);
	}

}
