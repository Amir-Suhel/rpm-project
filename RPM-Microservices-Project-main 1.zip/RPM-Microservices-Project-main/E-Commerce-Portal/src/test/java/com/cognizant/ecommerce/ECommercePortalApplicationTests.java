package com.cognizant.ecommerce;

import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ECommercePortalApplicationTests {

	@Test
	void contextLoads() {
		assertTrue(true);
	}

}
